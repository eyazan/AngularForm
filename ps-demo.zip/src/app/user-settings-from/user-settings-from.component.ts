import { Component, OnInit } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { UserSettings } from '../data/user-settings';
import { DataService } from '../data/data.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user-settings-from',
  templateUrl: './user-settings-from.component.html',
  styleUrls: ['./user-settings-from.component.css']
})
export class UserSettingsFromComponent implements OnInit {


      originalUserSettings : UserSettings = {
      name : 'Erdem',
      emailOffers : true,
      interfaceStyle: 'dark',
      subscriptionType: 'Annual',
      notes: 'here are some notes...'
  };

  singleModel = "On";
  startDate!: Date;
  startTime!: '';
  userSettings : UserSettings = {...this.originalUserSettings};
  // userRating: 0;
  // maxRating: 10;
  postError = false;
  postErrorMessage = '';
  subscriptionTypes: Observable<string[]> | undefined;

  constructor(private dataService:DataService) { }

  ngOnInit(): void {
    this.subscriptionTypes =  this.dataService.getSubscriptionTypes();
    this.startDate = new Date();
  }

  onSubmit(form: NgForm){
    console.log('in onSubmit: ', form.valid);

    if(form.valid){

   
    this.dataService.postUserSettingsForm(this.userSettings).subscribe(
      result => console.log('success: ',result),
      error => this.onHttpError(error)
    );
  }
  else {
    this.postError = true;
    this.postErrorMessage = "Please fix the above errors";
  }
}

  onBlur(field: NgModel){
    console.log('in onBlur: ', field.valid);
  }

  onHttpError(errorResponse : any){
    console.log('error: ',errorResponse);
    this.postError = true;
    this.postErrorMessage = errorResponse.error.errorMessage;
  }
}
function errorResponse(arg0: string, errorResponse: any) {
  throw new Error('Function not implemented.');
}

